#include<iostream>
using namespace std;
class A
{
public:
	int num1;
public:
	A( void ) : num1( 10 )
	{	}
};
class B : public A
{
public:
	int num1;
public:
	B( void ) : num1( 20 )
	{	}
};
int main( void )
{
	B obj;
	cout<<obj.A::num1<<endl;
	cout<<obj.num1<<endl;
	return 0;
}
