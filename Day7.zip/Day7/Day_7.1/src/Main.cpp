#include<cstdlib>
#include<iostream>
using namespace std;

void print( int number )
{
	cout<<"int"<<endl;
}
void print( int *number )
{
	cout<<"int*"<<endl;
}
int main( void )
{
	int number = 0;
	//print( number );	//int

	//print( &number );	//int*

	//print( NULL );	//call to 'print' is ambiguous

	print( nullptr );	//int*

	return 0;
}

class Complex
{
private:
	int real;
	int imag;
public:
	Complex( void )
	{
		cout<<"Inside constructor"<<endl;
		this->real = 10;
		this->imag = 20;
	}
};
int main7( void )
{
	//Complex *ptr = ( Complex* )malloc( sizeof( Complex) );
	Complex *ptr =  new Complex;
	return 0;
}
int main6( void )
{
	int count = 1000000000000;
	int *ptr = new int[ count ];
	if( ptr == NULL )
		cout<<"NULL"<<endl;
	else
		cout<<ptr<<endl;
	//Output : std::bad_alloc
	return 0;
}
int main5( void )
{
	int count = 1000000000000;
	void *ptr = malloc( count * sizeof( int ) );
	if( ptr == NULL )
		cout<<"NULL"<<endl;
	else
		cout<<ptr<<endl;
	//Output : NULL
	return 0;
}
int main4( void )
{
	int **ptr = new int*[ 2 ];
	for( int index = 0; index < 2; ++ index )
		ptr[ index ] = new int[ 3 ];

	for( int row = 0; row < 2; ++ row )
	{
		for( int col = 0; col < 3; ++ col )
		{
			cout<<"Enter element	:	";
			cin>>ptr[ row ][ col ];
		}
	}
	for( int row = 0; row < 2; ++ row )
	{
		for( int col = 0; col < 3; ++ col )
		{
			cout<<ptr[ row ][ col ]<<"	";
		}
		cout<<endl;
	}

	for( int index = 0; index < 2; ++ index )
		delete[] ptr[ index ];
	delete[] ptr;
	ptr = NULL;

	return 0;
}
int main3( void )
{
	int *ptr = new int[ 3 ];
	//int *ptr = ( int * )::operator new[](3 * sizeof( int ) );

	for( int index = 0; index < 3; ++ index )
	{
		cout<<"Enter element	:	";
		cin>>ptr[ index ];
	}

	for( int index = 0; index < 3; ++ index )
		cout<<ptr[ index ] <<endl;

	delete[] ptr;
	//::operator delete[](ptr);

	ptr = NULL;
	return 0;
}
int main2( void )
{
	//int *p1 = new int;

	//int *p2 = new int();

	//int *p3 = new int(3);
	return 0;
}
int main1( void )
{
	int *ptr = new int;
	//int *ptr = ( int* )::operator new(sizeof( int ) );

	*ptr = 125;	//Dereferencing
	cout<<"Value	:	"<<*ptr<<endl;//Dereferencing

	delete ptr;
	//::operator delete(ptr);

	ptr = NULL;
	return 0;
}
