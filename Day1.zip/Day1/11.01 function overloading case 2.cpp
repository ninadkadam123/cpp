#include<stdio.h>
//case 2 Function having same name and same number of arguments but
//differs in type of arguments
/*
int sum(int n2, int n1) // sum@@int, int
{
	return n1+n2;
}*/

float sum(int n1, float n2) // sum @@int,float
{
	return n1+n2;
}
int sum(int n1, int n2) // sum @@int,int
{
	return n1+n2;
}
int main()
{
	int result=0;
	float result1=0;

	result= sum(10, 20); // sum@@int, int
	printf("\n result=%d", result);


	result1= sum(10, 20.1f); // sum@@int, float
	printf("\n result1=%.2f", result1);


	return 0;
}
