#include<stdio.h>
#pragma pack(1) //-- struct member alligment 1 byte
struct emp
{
	int empno;
	char name[10];
	float sal;
};
//slack bytes
void AcceptEmpInfo(struct emp *e); // e 4 or 8 bytes
//void DisplayEmpInfo(struct emp e); // e 18 bytes
void DisplayEmpInfo(const struct emp *e); // e 18 bytes
void SetSalary(struct emp *e, float sal);
float GetSalary(const struct emp *e);

int main(void)
{
	// struct emp is user defined data type
	// e1 is variable (object ) of user defined data type struct emp
	struct emp e1={1};
	float newsal;

	printf("\n Enter Emp info :: \n");
	AcceptEmpInfo(&e1); // e1 is actual argument

	printf("\n Emp info :: in main  \n");
	DisplayEmpInfo(&e1);

	printf("\n Enter New sal :: ");
	scanf("%f", &newsal);
	SetSalary(&e1,newsal);

	newsal= GetSalary(&e1);
	printf("\n Updated sal =%.2f", newsal);
	printf("\n Updated sal =%.2f", GetSalary(&e1));

	printf("\n Emp info :: in main  \n");
	DisplayEmpInfo(&e1);


	return 0;
}
void AcceptEmpInfo(struct emp *e)
{
	printf("\n Enter EmpNo :: ");
	scanf("%d", &e->empno);

	printf("\n Enter EmpName :: ");
	scanf("%s", e->name);

	printf("\n Enter Emp sal :: ");
	scanf("%f", &e->sal);


	return;
}
void DisplayEmpInfo(const struct emp *e)
{
	//e->sal=-10000; // errror as e is const
	printf("\n Emp No    Name    sal  using struct variable e \n");
	printf("%-8d%-10s%6.2f", e->empno, e->name, e->sal);
	return;
}
void SetSalary(struct emp *e, float sal)
{
	e->sal= sal;
	return ;
}
float GetSalary(const struct emp *e)
{
	return e->sal;
}
