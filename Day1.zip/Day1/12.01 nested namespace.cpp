#include<stdio.h>

namespace N1
{
	int no1=500;
	int no2=700;
	namespace N2
	{
		int no1=1500;
		int no3=800;
	}
}
int no1=100; // global variable
using namespace N1;
//using namespace N1::N2; // or
//using namespace N2;
int main()
{
	int no1=10; // local variable
	printf("\n no1=%d no1=%u local variable", no1, &no1);// local variable
	printf("\n ::no1=%d ::no1=%u global variable", ::no1, &::no1); // global variable

	// namespace N1
	// namespacename::variablename
	printf("\n N1::no1=%d N1::no1=%u  variable from namespace N1", N1::no1, &N1::no1);
	printf("\n N1::no2=%d N1::no2=%u variable no2 from namespace N1", N1::no2, &N1::no2);

	printf("\n====================================\n");
	printf("\nvariables from namespace N1\n =========================================\n");

//	using namespace N1;
	printf("\n N1::no1=%d N1::no1=%u  namespace N1  variable no1 ", N1::no1, &N1::no1);
	printf("\n no2=%d no2=%u variable no2 from namespace N1",no2, &no2);
	printf("\n no1=%d no1=%u  local variable no1 ", no1, &no1);

	printf("\n====================================\n");
	printf("\n variables from namespace N1::N2\n=========================================\n");

	printf("\n N1::N2::no1=%d [%u] no1 from Namespace N1::N2  ", N1::N2::no1, &N1::N2::no1);
	printf("\n N1::N2::no3=%d [%u] no3 from Namespace N1::N2  ", N1::N2::no3, &N1::N2::no3);

	//using namespace N1::N2;
    // or
	using namespace N1;
	using namespace N2;
	printf("\n no3=%d [%u] no3 from Namespace N1::N2  ", no3, &no3);
	printf("\n N1::N2::no1=%d [%u] no1 from Namespace N1::N2  ", N1::N2::no1, &N1::N2::no1);
	return 0;
}

