#include<stdio.h>
#define sq(a) a*a // not type safe they dont have data type
inline int square(int a);// type safe   they have data type

int main()
{
	int x=5, y=0;
	y= sq(x); // y= x*x // y= 5*5 == 25
	printf("\n x=%d y=%d", x, y);

	y= sq(x+x); // y= x+x*x+x // y= 5+5*5+5 == 5+25+5 == 35
	printf("\n x=%d y=%d", x, y);

	y= square(x); //y= return x*x;
	printf("\n x=%d y=%d", x, y);
	return 0;
}
inline int square(int a)
{
	return a*a;
}


 // compile ---> g++ demo2.cpp --->> a.out
 // for .i file--->> g++ -E -o demo2.i demo2.out

