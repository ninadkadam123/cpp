#include<stdio.h>
#pragma pack(1) //-- struct member alligment 1 byte
// way1
/*typedef enum menuchoice
{
	EXIT,ACCEPT_INFO, DISPLAY_INFO, UPDATE_SAL, PRINT_SAL
	//0     1            2            3           4
}MENUCHOICE;*/
// way2 for enum
enum menuchoice
{
	EXIT,ACCEPT_INFO, DISPLAY_INFO, UPDATE_SAL, PRINT_SAL
	//0     1            2            3           4
};
typedef enum menuchoice MENUCHOICE;

struct emp
{

	private:
	// variables or data members or fields
	int empno;
	char name[10];
	float sal;

	public:
	// member function or methods
	//void AcceptEmpInfo(struct emp * const this)
	// e1.AcceptEmpInfo(); -->> this=&e1;
	void AcceptEmpInfo()
	{
		printf("\n Enter EmpNo :: ");
		scanf("%d", &this->empno);

		printf("\n Enter EmpName :: ");
		scanf("%s", this->name);

		printf("\n Enter Emp sal :: ");
		scanf("%f", &this->sal);
		return;
	}
	//void DisplayEmpInfo(struct emp * const this)
	//void DisplayEmpInfo( emp * const this)
	void DisplayEmpInfo()
	{

		printf("\n Emp No    Name    sal   \n");
		printf("%-8d%-10s%6.2f", this->empno, this->name, this->sal);
		return;
	}
	//void SetSalary( struct emp * const this, float sal)
	inline void SetSalary( float sal)
	{
		this->sal= sal;
		return ;
	}

	//float GetSalary(struct emp * const this)
	inline float GetSalary()
	{
		return this->sal;
	}
};

//slack bytes
int MenuOperations();
int main(void)
{
	// struct emp is user defined data type
	// e1 is variable (object ) of user defined data type struct emp

	emp e1; //struct emp e1={1};
	float newsal;
	MENUCHOICE choice; //enum menuchoice choice;

	do
	{
		choice= (enum menuchoice)MenuOperations();
		switch(choice)
		{
			default: printf("\n invalid case "); //break;
				continue; // go to next itration in do while

			case EXIT : // exit(0);
					return 0;
			case  ACCEPT_INFO: // accept emp info
					printf("\n Enter Emp info :: \n");
					//AcceptEmpInfo(&e1); // e1 is actual argument
					e1.AcceptEmpInfo();
					break;
			case DISPLAY_INFO: // print emp info
					printf("\n Emp info :: in main  \n");
					//DisplayEmpInfo(&e1);
					e1.DisplayEmpInfo();
					break;
			case UPDATE_SAL: // update sal
					printf("\n Enter New sal :: ");
					scanf("%f", &newsal);
					//SetSalary(&e1,newsal);
					e1.SetSalary(newsal);
					break;
			case PRINT_SAL: // print new sal

				//newsal= GetSalary(&e1);
				newsal= e1.GetSalary();
				printf("\n Updated sal =%.2f", newsal);
//				printf("\n Updated sal =%.2f", GetSalary(&e1));
				printf("\n Updated sal =%.2f", e1.GetSalary());
				printf("\n Emp info :: in main  \n");
				e1.DisplayEmpInfo();//DisplayEmpInfo(&e1);
		}

		printf("\n Enter 1 to continue or 0 to Exit :: ");
		scanf("%d", &choice);

	}while(choice!=0);

	return 0;
}

int MenuOperations()
{
	int choice;
	printf("\n 1. Accept Emp info \n 2. Print Emp info ");
	printf("\n 3. update sal \n 4. Print updated sal \n 0. Exit ");

	printf("\n Enter Your choice :: ");
	scanf("%d", &choice);

	return choice;
}
