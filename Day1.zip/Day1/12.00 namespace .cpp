#include<stdio.h>
namespace N1
{
	int no1=500;
	int no2=700;
}

int no1=100; // global variable

using namespace N1;
int main()
{
	int no1=10; // local variable
	printf("\n no1=%d no1=%u local variable", no1, &no1);
	printf("\n ::no1=%d ::no1=%u global variable", ::no1, &::no1); // global
	// namespace N1
	// namespacename::variablename
	printf("\n N1::no1=%d N1::no1=%u  variable from namespace N1", N1::no1, &N1::no1);
	printf("\n N1::no2=%d N1::no2=%u variable no2 from namespace N1", N1::no2, &N1::no2);

//	using namespace N1;

	printf("\n N1::no1=%d N1::no1=%u  namespace N1  variable no1 ", N1::no1, &N1::no1);
	printf("\n no2=%d no2=%u variable no2 from namespace N1",no2, &no2);
	printf("\n no1=%d no1=%u  local variable no1 ", no1, &no1);


	return 0;
}
