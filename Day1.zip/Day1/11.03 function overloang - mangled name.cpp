#include<iostream>
using namespace std;
int sum()
{
}
int sum(int)
{
}
int sum(int, int)
{
}

int main()
{
	return 0;
}

//======================================
//to compile          ----> g++ demo1.cpp
//to check mangle name ---> nm a.out
