#include<stdio.h>
#pragma pack(1) //-- struct member alligment 1 byte
// way1
/*typedef enum menuchoice
{
	EXIT,ACCEPT_INFO, DISPLAY_INFO, UPDATE_SAL, PRINT_SAL
	//0     1            2            3           4
}MENUCHOICE;*/
// way2 for enum
enum menuchoice
{
	EXIT,ACCEPT_INFO, DISPLAY_INFO, UPDATE_SAL, PRINT_SAL
	//0     1            2            3           4
};
typedef enum menuchoice MENUCHOICE;

struct emp
{
	int empno;
	char name[10];
	float sal;
};
//slack bytes
void AcceptEmpInfo(struct emp *e); // e 4 or 8 bytes
//void DisplayEmpInfo(struct emp e); // e 18 bytes
void DisplayEmpInfo(const struct emp *e); // e 18 bytes
void SetSalary(struct emp *e, float sal);
float GetSalary(const struct emp *e);
int MenuOperations();
int main(void)
{
	// struct emp is user defined data type
	// e1 is variable (object ) of user defined data type struct emp

	struct emp e1={1};
	float newsal;
	MENUCHOICE choice; //enum menuchoice choice;

	do
	{
		choice= (enum menuchoice)MenuOperations();
		switch(choice)
		{
			default: printf("\n invalid case "); //break;
				continue; // go to next itration in do while

			case EXIT : // exit(0);
					return 0;
			case  ACCEPT_INFO: // accept emp info
					printf("\n Enter Emp info :: \n");
					AcceptEmpInfo(&e1); // e1 is actual argument
					break;
			case DISPLAY_INFO: // print emp info
					printf("\n Emp info :: in main  \n");
					DisplayEmpInfo(&e1);
					break;
			case UPDATE_SAL: // update sal
					printf("\n Enter New sal :: ");
					scanf("%f", &newsal);
					SetSalary(&e1,newsal);
					break;
			case PRINT_SAL: // print new sal

				newsal= GetSalary(&e1);
				printf("\n Updated sal =%.2f", newsal);
				printf("\n Updated sal =%.2f", GetSalary(&e1));
				printf("\n Emp info :: in main  \n");
				DisplayEmpInfo(&e1);
		}

		printf("\n Enter 1 to continue or 0 to Exit :: ");
		scanf("%d", &choice);

	}while(choice!=0);

	return 0;
}
void AcceptEmpInfo(struct emp *e)
{
	printf("\n Enter EmpNo :: ");
	scanf("%d", &e->empno);

	printf("\n Enter EmpName :: ");
	scanf("%s", e->name);

	printf("\n Enter Emp sal :: ");
	scanf("%f", &e->sal);


	return;
}
void DisplayEmpInfo(const struct emp *e)
{
	//e->sal=-10000; // errror as e is const
	printf("\n Emp No    Name    sal  using struct variable e \n");
	printf("%-8d%-10s%6.2f", e->empno, e->name, e->sal);
	return;
}
void SetSalary(struct emp *e, float sal)
{
	e->sal= sal;
	return ;
}
float GetSalary(const struct emp *e)
{
	return e->sal;
}
int MenuOperations()
{
	int choice;
	printf("\n 1. Accept Emp info \n 2. Print Emp info ");
	printf("\n 3. update sal \n 4. Print updated sal \n 0. Exit ");

	printf("\n Enter Your choice :: ");
	scanf("%d", &choice);

	return choice;
}
