#include<stdio.h>
/*int sum(int n1=0, int n2=0, int n3=0, int n4=0)
{
	printf("\n n1=%d n2=%d n3=%d n4=%d", n1,n2, n3, n4);
	return n1+n2+n3+n4;
}*/
int sum(int n1=0, int n2=0, int n3=0, int n4=0);
int main()
{
	int result=0;
	result =sum(10,20,30,40);
	printf("\n result =%d", result);

	result =sum(10,20,30);
	printf("\n result =%d", result);

	result =sum(10,20);
	printf("\n result =%d", result);

	result =sum(10);
	printf("\n result =%d", result);

	result =sum();
	printf("\n result =%d", result);


	return 0;
}
int sum(int n1, int n2, int n3, int n4)
{
	printf("\n n1=%d n2=%d n3=%d n4=%d", n1,n2, n3, n4);
	return n1+n2+n3+n4;
}
