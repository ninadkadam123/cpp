#include<stdio.h>

// 2 data types added in cpp
//1. bool == TRUE of FALSE 1 byte
//2. wchar_t == 16 bit char unicode
//   char  8 == bit ascii - english
/*int f1(int) // f1@@int
{
	printf("\ninside int block");
}
*/
void f1(int) // f1@@int
{
	printf("\ninside int block");
}
void f1(char) // f1@@char
{
	printf("\ninside char block");
}
void f1(float) // f1@@float
{
	printf("\ninside float block");
}
void f1(double) // f1@@double
{
	printf("\ninside double block");
}
void f1(char*) // f1@@char*
{
	printf("\ninside char*(string) block");
}
void f1(bool) // f1@@bool
{
	printf("\n inside bool block");
}
int main()
{
	f1(10); // inside int block
	f1(10.10); //  inside double  block
	f1(10.10f); //  inside float block
	f1(10.10F); //  inside float block
	f1((int)10.10); // inside int block
	f1('a');// inside char block
	f1("Sunbeam");// inside char*(string) block
	f1((float)10.10);// inside float block
	f1(true); // inside bool block
	f1(false); // inside bool block
	return 0;
}
