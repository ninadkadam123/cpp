#include<stdio.h>
#pragma pack(1) //-- struct member alligment 1 byte
struct emp
{
	int empno;
	char name[10];
	float sal;
};
//slack bytes
void AcceptEmpInfo(struct emp e);
void DisplayEmpInfo(struct emp e);
int main(void)
{
	// struct emp is user defined data type
	// e1 is variable (object ) of user defined data type struct emp
	struct emp e1;
	printf("\n Enter Emp info :: \n");
	AcceptEmpInfo(e1); // e1 is actual argument

	printf("\n Emp info :: in main  print garbage values \n");
	DisplayEmpInfo(e1);

	return 0;
}
void AcceptEmpInfo(struct emp e)
{
	printf("\n Enter EmpNo :: ");
	scanf("%d", &e.empno);

	printf("\n Enter EmpName :: ");
	scanf("%s", e.name);

	printf("\n Enter Emp sal :: ");
	scanf("%f", &e.sal);

	printf("\n Emp info :: in Accept  print output correctly\n");
	DisplayEmpInfo(e);

	return;
}
void DisplayEmpInfo(struct emp e)
{
	printf("\n Emp No    Name    sal  using struct variable e \n");
	printf("%-8d%-10s%6.2f", e.empno, e.name, e.sal);
	return;
}
