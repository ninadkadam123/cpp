#include<stdio.h>
#pragma pack(1) //-- struct member alligment 1 byte
struct emp
{
	int empno;
	char name[10];
	float sal;
};
//slack bytes
int main(void)
{
	// struct emp is user defined data type
	// e1 is variable (object ) of user defined data type struct emp
	struct emp e1;
	struct emp *ptr=&e1;
	printf("\n size of e1=%d", sizeof(e1));
	printf("\n size of ptr=%d",sizeof(ptr));
	printf("\n Enter Emp info :: \n");
	printf("\n Enter EmpNo :: ");
	scanf("%d", &e1.empno);

	printf("\n Enter EmpName :: ");
	scanf("%s", e1.name);

	printf("\n Enter Emp sal :: ");
	scanf("%f", &e1.sal);

	printf("\n Emp No    Name    sal  using struct variable e1 \n");
	printf("%-8d%-10s%6.2f", e1.empno, e1.name, e1.sal);

	printf("\n Emp No    Name    sal  using pointer ptr \n");
	printf("%-8d%-10s%6.2f", ptr->empno, ptr->name, ptr->sal);

	printf("\n Emp No    Name    sal  using pointer ptr \n");
	printf("%-8d%-10s%6.2f", (*ptr).empno, (*ptr).name, (*ptr).sal);

	printf("\n ptr=%u ptr+1=%u ", ptr,ptr+1);
	printf("\n &e1=%u &e1+1=%u ", &e1,&e1+1);

	return 0;
}
