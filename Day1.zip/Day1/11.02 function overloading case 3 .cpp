#include<stdio.h>
//case 3 Function having same name ,same number of arguments but order
//of arguments are different
/*
int sum(int n2, int n1) // sum@@int, int
{
	return n1+n2;
}*/

float sum(int n1, float n2) // sum @@int,float
{
	return n1+n2;
}
float sum(float n1, int n2) // sum @@float,int
{
	return n1+n2;
}
int main()
{

	float result1=0;

	result1= sum(10, 20.2f); // sum@@int, float
	printf("\n result1=%.2f", result1);


	result1= sum( 20.1f,100); // sum@@int, float
	printf("\n result1=%.2f", result1);
	printf("\n result1=%.0f", result1);


	return 0;
}
