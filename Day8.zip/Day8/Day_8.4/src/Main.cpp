#include<iostream>
using namespace std;

class Test
{
private:
	int num1;			//Instance Variable
	int num2;			//Instance Variable
	static int num3;	//Class Level Variable
public:
	Test( void )
	{
		this->num1 = 0;
		this->num2 = 0;
	}
	void setNum1( int num1 )
	{
		this->num1 = num1;
	}
	void setNum2( int num2 )
	{
		this->num2 = num2;
	}
	static void setNum3( int num3 )
	{
		Test::num3 = num3;
	}
	//Test *const this = &t1
	void printRecord( void )
	{
		cout<<"Num1	:	"<<this->num1<<endl;
		cout<<"Num2	:	"<<this->num2<<endl;
		cout<<"Num3	:	"<<Test::num3<<endl;
	}
};
int Test::num3;	//Global Definition

class Math
{
public:
	static int pow( int base, int index )
	{
		int result = 1;
		for( int count = 1; count <= index; ++ index )
			result = result * base;
		return result;
	}
};
int main( void )
{
	Test t;
	t.printRecord();
	return 0;
}
