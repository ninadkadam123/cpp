#include<iostream>
using namespace std;
class Matrix
{
private:
	int row;
	int col;
	int **arr;
public:
	Matrix( void )
	{
		cout<<"Matrix( void ) : "<<this<<endl;
		this->row = 0;
		this->col = 0;
		this->arr = NULL;
	}
	Matrix( int row, int col )
	{
		cout<<"Matrix( int row, int col ) : "<<this<<endl;
		this->row = row;
		this->col = col;
		this->arr = new int*[ this->row ];
		for( int index = 0; index < this->row; ++ index )
			this->arr[ index ] = new int[ this->col ];
	}
	Matrix( const Matrix &other )
	{
		cout<<"Matrix( const Matrix &other ) : "<<this<<endl;
		this->row = other.row;
		this->col = other.col;

		this->arr = new int*[ this->row ];
		for( int index = 0; index < this->row; ++ index )
			this->arr[ index ] = new int[ this->col ];

		for( int i = 0; i < this->row; ++ i )
		{
			for( int j = 0; j < this->col; ++ j )
			{
				this->arr[ i ][ j ] = other.arr[ i ][ j ];
			}
		}
	}

	void acceptRecord( void )
	{
		for( int i = 0; i < this->row; ++ i )
		{
			for( int j = 0; j < this->col; ++ j )
			{
				cout<<"Enter element	:	";
				cin>>this->arr[ i ][ j ];
			}
		}
	}
	//Matrix *const this = &m1
	//Matrix other = m2
	Matrix sum( Matrix other )
	{
		Matrix temp(this->row, this->col );
		for( int i = 0; i < this->row; ++ i )
		{
			for( int j = 0; j < this->col; ++ j )
			{
				temp.arr[ i ][ j ] = this->arr[ i ][ j ] + other.arr[ i ][ j ];
			}
		}
		return temp;
	}
	void printRecord( void )
	{
		for( int i = 0; i < this->row; ++ i )
		{
			for( int j = 0; j < this->col; ++ j )
			{
				cout<<this->arr[ i ][ j ]<<"	";
			}
			cout<<endl;
		}
	}
	~Matrix( void )
	{
		cout<<"~Matrix( void ) : "<<this<<endl;
		if( this->arr != NULL )
		{
			for( int index = 0; index < this->row; ++ index )
				delete[] this->arr[ index ];
			delete[] this->arr;
			this->arr = NULL;
		}
	}
};
int main( void )
{
	Matrix m1(2,3);
	m1.acceptRecord( );
	Matrix m2(2,3);
	m2.acceptRecord( );
	Matrix m3 = m1.sum( m2 );
	m3.printRecord( );
	return 0;
}
