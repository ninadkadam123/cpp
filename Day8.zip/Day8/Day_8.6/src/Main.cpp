#include<iostream>
using namespace std;

class Singleton
{
private:
	int number;
private:
	Singleton( void )
	{
		this->number = 0;
	}
	Singleton( const Singleton &other )
	{
		this->number = other.number;
	}
public:
	int getNumber( void )
	{
		return this->number;
	}
	void setNumber( int number )
	{
		this->number = number;
	}
	static Singleton& getInstance( void )
	{
		static Singleton instance;
		return instance;
	}
};
int main( void )
{
	Singleton& s1 =  Singleton::getInstance();
	s1.setNumber(10);
	cout<<"Number	:	"<<s1.getNumber()<<endl;
	return 0;
}
