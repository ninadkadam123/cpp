#include<iostream>
using namespace std;

class Test
{
private:
	int num1;			//Instance Variable
	int num2;			//Instance Variable
	static int num3;	//Class Level Variable
public:
	Test( int num1 = 0, int num2 = 0 )
	{
		this->num1 = num1;
		this->num2 = num2;
		//Test::num3 = 550;
	}
	//Test *const this = &t1
	void printRecord( void )
	{
		cout<<"Num1	:	"<<this->num1<<endl;
		cout<<"Num2	:	"<<this->num2<<endl;
		cout<<"Num3	:	"<<Test::num3<<endl;
	}
};
int Test::num3 = 500;	//Global Definition
int main( void )
{
	Test t1(10,20);
	t1.printRecord( );
	return 0;
}
