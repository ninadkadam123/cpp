#include<iostream>
#include<string>
using namespace std;
class Date
{
private:
	int day;	//
	int month;	//
	int year;	//
public:
	Date( void ) : day( 0 ), month( 0 ), year (0 )
	{	}
	Date( int day, int month, int year ) : day( day ), month( month ), year ( year )
	{	}
	void printRecord( void )
	{
		cout<<this->day<<" / "<<this->month<<" / "<<this->year<<endl;
	}
};
class Employee
{
private:
	string name;	//Association
	Date joinDate;	//Association
public:
	Employee( void )
	{	}
	Employee( string name, Date joinDate ) : name( name ), joinDate( joinDate )
	{	}
	Employee( string name, int day, int month, int year ) : name( name ), joinDate( day, month, year )
	{	}
	void printRecord( void )
	{
		cout<<"Name	:	"<<this->name<<endl;
		cout<<"Join Date	:	";
		this->joinDate.printRecord();
	}
};
int main( void )
{
	Employee emp("Sandeep", 26,12,2006 );
	emp.printRecord();
	return 0;
}

int main1( void )
{
	string name = "Sandeep";
	Date joinDate(26,12,2006);
	Employee emp(name, joinDate );
	emp.printRecord();
	return 0;
}
