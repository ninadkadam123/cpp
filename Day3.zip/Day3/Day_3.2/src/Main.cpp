#include<stdio.h>
struct Employee
{
//public:
	char name[ 50 ];	//50 bytes
	int empid;			//4 bytes
	float salary;		//4 bytes
//public:
	void accept_record( /*struct Employee *ptr */ )
	{
		printf("Name	:	");
		scanf("%s", name);
		printf("Empid	:	");
		scanf("%d", &empid);
		printf("Salry	:	");
		scanf("%f", &salary);
	}
	void print_record( /*struct Employee *ptr */ )
	{
		printf("Name	:	%s\n", name);
		printf("Empid	:	%d\n",empid);
		printf("Salary	:	%f\n", salary);
	}
};


int main( void )
{
	Employee emp;

	emp.accept_record(  );	//emp.accept_record( &emp );

	emp.salary = -50000;

	emp.print_record( );	//emp.print_record( &emp );
	return 0;
}
