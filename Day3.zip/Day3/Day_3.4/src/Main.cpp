#include<stdio.h>
class Employee
{
private:
	char name[ 50 ];
	int empId;
	float salary;
public:
	void acceptRecord( void  );

	void printRecord( void );
};//end of class Employee

void Employee::acceptRecord( void  )
{
	printf("Name	:	");
	scanf("%s", name);
	printf("Empid	:	");
	scanf("%d", &empId);
	printf("Salry	:	");
	scanf("%f", &salary);
}
void Employee::printRecord( void )
{
	printf("Name	:	%s\n", name);
	printf("Empid	:	%d\n",empId);
	printf("Salary	:	%f\n", salary);
}
int main( void )
{
	Employee emp;

	emp.acceptRecord( );

	emp.printRecord();

	return 0;
}
