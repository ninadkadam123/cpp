#include<stdio.h>
struct Employee
{
	char name[ 50 ];	//50 bytes
	int empid;			//4 bytes
	float salary;		//4 bytes
};
void accept_record( struct Employee *ptr )
{
	printf("Name	:	");
	scanf("%s", ptr->name);
	printf("Empid	:	");
	scanf("%d", &ptr->empid);
	printf("Salry	:	");
	scanf("%f", &ptr->salary);
}
void print_record( struct Employee *ptr )
{
	printf("Name	:	%s\n", ptr->name);
	printf("Empid	:	%d\n",ptr->empid);
	printf("Salary	:	%f\n", ptr->salary);
}
/*void accept_record( struct Employee emp )
{
	printf("Name	:	");
	scanf("%s", emp.name);
	printf("Empid	:	");
	scanf("%d", &emp.empid);
	printf("Salry	:	");
	scanf("%f", &emp.salary);
}
void print_record( struct Employee emp )
{
	printf("Name	:	%s\n", emp.name);
	printf("Empid	:	%d\n",emp.empid);
	printf("Salary	:	%f\n", emp.salary);
}*/
int main( void )
{
	//struct Employee emp={"Sandeep",33,45000.50f};
	struct Employee emp;

	accept_record( &emp );

	print_record( &emp );
	return 0;
}
