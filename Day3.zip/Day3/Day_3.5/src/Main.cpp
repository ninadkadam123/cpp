#include"../include/Employee.h"
int main( void )
{
	Employee emp;

	emp.acceptRecord( );

	emp.printRecord();

	return 0;
}
