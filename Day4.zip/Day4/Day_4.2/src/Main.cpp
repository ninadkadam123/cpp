#include<stdio.h>

class Complex
{
private:
	int real;
	int imag;
public:
	//Complex *const this = & current object
	void acceptRecord( void )
	{
		printf("Real Number	:	");
		scanf("%d", &this->real);
		printf("Imag Number	:	");
		scanf("%d", &this->imag);
	}
	//Complex *const this = &c1
	//Complex other = c2;
	Complex sum( Complex other )
	{
		Complex temp;
		temp.real = this->real + other.real;
		temp.imag = this->imag + other.imag;
		return temp;
	}
	//Complex *const this = &current object
	void printRecord( void )
	{
		printf("Real Number	:	%d\n", this->real);
		printf("Imag Number	:	%d\n", this->imag);
	}
};
int main( void )
{
	Complex c1;
	c1.acceptRecord( );	//c1.acceptRecord( &c1 );

	Complex c2;
	c2.acceptRecord();	//c2.acceptRecord( &c2 );

	Complex c3;
	c3 = c1.sum( c2 );	//c3 = c1.sum( &c1, c2  );


	c3.printRecord( );

	return 0;
}
