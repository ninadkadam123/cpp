#include<stdio.h>
#include<iostream>
using namespace std;

class Complex
{
private:
	int real;
	int imag;
public:
	//Complex *const this = &c1;
	Complex( void )
	{
		printf("Complex( void )	:	%p\n", this );
		this->real = 0;
		this->imag = 0;
	}
	//Complex *const this = & current object
	void acceptRecord( void )
	{
		printf("Real Number	:	");
		scanf("%d", &this->real);
		printf("Imag Number	:	");
		scanf("%d", &this->imag);
	}
	//Complex *const this = &current object
	void printRecord( void )
	{
		printf("Real Number	:	%d\n", this->real);
		printf("Imag Number	:	%d\n", this->imag);
	}

};

int main( void )
{

	return 0;
}
