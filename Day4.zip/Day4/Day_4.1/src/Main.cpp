#pragma pack(1)
#include<stdio.h>
struct Employee
{
private:
	char name[ 30 ];	//30 bytes
	int empId;			//4 bytes
	float salary;		//4 bytes
public:
	void acceptRecord( void )
	{
		printf("Name	:	");
		scanf("%s", name );
		printf("Empid	:	");
		scanf("%d", &empId );
		printf("Salary	:	");
		scanf("%f", &salary );
	}
	void printRecord(  void  )
	{
		//printf("Name	:	%s\n", name );
		printf("Name	:	%s\n", this->name );

		//printf("Empid	:	%d\n", empId );
		printf("Empid	:	%d\n", this->empId );

		//printf("Salary	:	%f\n", salary );
		printf("Salary	:	%f\n", this->salary );
	}
};
int main( void )
{
	Employee emp;
	emp.acceptRecord( );
	emp.printRecord( );
	return 0;
}






