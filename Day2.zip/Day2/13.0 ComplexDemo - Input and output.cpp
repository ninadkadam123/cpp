#include <iostream>
using namespace std;
namespace NComplex
{
	class Complex
	{
		private:
		// variables or data member or fields
			int real;
			int imag;

		public:
			// member functions or methods
			//1.1 input
			//void AcceptInputFromConsole(Complex * const this)
			void AcceptInputFromConsole()
			{
				cout<<"Enter Real ::";
				cin>>this->real;
				cout<<"Enter Imag ::";
				cin>>this->imag;
			}
			//1.2 output
			//void PrintOutputOnConsole(Complex * const this)
			void PrintOutputOnConsole()
			{
				cout<<"this->real ::"<<this->real<<" [ "<< &this->real <<" ] "<<endl;
				cout<<"this->imag ::"<<this->imag<<" [ "<< &this->imag <<" ] "<<endl;
			}


	}; //end of Complex class
}//end of NComplex namespace
//using namespace NComplex;
int main()
{
	NComplex::Complex c1;
	using namespace NComplex;
	Complex c2;

	cout<<"Enter Value for c1:: "<<endl;
	c1.AcceptInputFromConsole();
	cout<<"c1 :: "<<endl;
	c1.PrintOutputOnConsole();
	cout<<"size of c1= "<<sizeof(c1)<<endl;

	cout<<"Enter Value for c2:: "<<endl;
	c2.AcceptInputFromConsole();
	cout<<"c2 :: "<<endl;
	c2.PrintOutputOnConsole();
	cout<<"size of c2= "<<sizeof(c2)<<endl;



	return 0;
}
