#include <iostream>
using namespace std;
namespace NComplex
{
	class Complex
	{
		private:
		// variables or data member or fields
			int real;
			int imag;

		public:
			// member functions or methods
			//1.1 input
			//void AcceptInputFromConsole(Complex * const this)
			void AcceptInputFromConsole()
			{
				cout<<"Enter Real ::";
				cin>>this->real;
				cout<<"Enter Imag ::";
				cin>>this->imag;
			}
			//1.2 output
			void PrintOutputOnConsole()
			{
				cout<<"this->real ::"<<this->real<<" [ "<< &this->real <<" ] "<<endl;
				cout<<"this->imag ::"<<this->imag<<" [ "<< &this->imag <<" ] "<<endl;
			}

			//2 setter methods modify the state of object (mutators)
			//void SetReal(Complex * const this, int real)
			void SetReal(int real)
			{
				this->real= real;
			}
			//void SetImag(Complex * const this,  int imag)
			void SetImag(int imag)
			{
				this->imag= imag;
			}
			//3. getter methods dont modify state of object (Inspectors)
			//int GetReal(Compelx *const this )
			int GetReal()
			{
				return this->real;
			}
			//int GetImag(Complex * const this)
			int GetImag()
			{
				return this->imag;
			}
			//4.1 parameterless ctor
			//Complex(Comnplex * const this)
			Complex()
			{
				this->real=10;
				this->imag=20;
				cout<<"inside parameterless ctor of Complex class"<<endl;
			}
			//4.2 paramterized ctor one argument
			Complex (int value)
			{
				this->real= value;
				this->imag= value;
				cout<<"inside parameterized ctor( with one arguments ) of Complex class"<<endl;
			}

			//4.3 paramterized ctor two arguments
			Complex (int real, int imag)
			{
				this->real= real;
				this->imag= imag;
				cout<<"inside parameterized (two arguments )ctor of Complex class"<<endl;
			}
			//4.4 paramterized ctor with default arguments
			/*Complex (int real=10, int imag=20)
			{
				this->real= real;
				this->imag= imag;
				cout<<"inside parameterized with default aguments ctor of Complex class"<<endl;
			}*/

			~Complex()
			{
				cout<<"======================"<<endl;
				this->PrintOutputOnConsole();
				this->real=0;
				this->imag=0;
				cout<<"inside dtor of Complex class"<<endl;
			}

	}; //end of Complex class
}//end of NComplex namespace
using namespace NComplex;
int main()
{

	Complex c1; // parameter less ctor
	cout<<"c1 :: "<<endl;
	c1.PrintOutputOnConsole();
	int real,imag;

	cout<<"Enter real :: ";
	cin>>real;
	cout<<"Enter imag :: ";
	cin>>imag;

//	Complex c2(11,22); // paramterized ctor
	Complex c2(real,imag); // paramterized ctor
	cout<<"c2 :: "<<endl;
	c2.PrintOutputOnConsole();

	int value;
	cout<<"Enter value :: ";
	cin>>value;

	Complex c3(value);
	cout<<"c3 :: "<<endl;
	c3.PrintOutputOnConsole();


	return 0;
}
