#include <iostream>
using namespace std;
namespace NCircle
{
	class Circle
	{
		private:
			double radius;
			double area;

		public:
			Circle()
			{
				this->radius=5.0;
				this->area=0.0;
				cout<<"inside parameterless ctor of circle class "<<endl;
			}
			Circle(double radius)
			{
				this->radius=radius;
				this->area=0.0;
				cout<<"inside parameterized (one arguments) ctor of circle class "<<endl;
			}

			void SetRadius(double radius)
			{
				this->radius=radius;
			}

			double GetRadius()
			{
				return this->radius;
			}
			void CalculateArea()
			{
				this->area= 3.142 * this->radius * this->radius;
			}

			void AcceptInputFromConsole()
			{
				cout<<"Enter Radius ::";
				cin>>this->radius;
			}

			void PrintOutPutOnConsole()
			{
				cout<<"this->radius:: "<<this->radius<<endl;
				cout<<"this->area :: "<<this->area<<endl;
			}
			~Circle()
			{
				this->radius=0.0;
				cout<<"inside dtor of circle class "<<endl;
			}


	};//end of class  Circle
}//end of namespace
using namespace NCircle;
int main()
{
	Circle c1;
	//c1.AcceptInputFromConsole();
	c1.CalculateArea();
	c1.PrintOutPutOnConsole();

	double r;
	cout<< " Enter radius :: ";
	cin>>r;
	Circle c2(r);
	//c2.SetRadius(r);
	c2.CalculateArea();
	cout<<"c2 :: "<<endl;
	c2.PrintOutPutOnConsole();


	return 0;
}
