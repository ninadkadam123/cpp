#include <iostream>
using namespace std;
namespace NCircle
{
	class Circle
	{
		private:
			double radius;
			double area;

		public:
			Circle();
			Circle(double radius);
			void SetRadius(double radius);
			double GetRadius();
			void CalculateArea();
			void AcceptInputFromConsole();
			void PrintOutPutOnConsole();
			~Circle();
	};//end of class  Circle


	//returntype ClassName::MemberFunName(datatype parameters)
		Circle:: Circle()
		{
			this->radius=5.0;
			this->area=0.0;
			cout<<"inside parameterless ctor of circle class "<<endl;
		}

		Circle::Circle(double radius)
		{
			this->radius=radius;
			this->area=0.0;
			cout<<"inside parameterized (one arguments) ctor of circle class "<<endl;
		}

		void Circle::SetRadius(double radius)
		{
			this->radius=radius;
		}

		double Circle:: GetRadius()
		{
			return this->radius;
		}
		void Circle:: CalculateArea()
		{
			this->area= 3.142 * this->radius * this->radius;
		}

		void  Circle:: AcceptInputFromConsole()
		{
			cout<<"Enter Radius ::";
			cin>>this->radius;
		}

		void Circle:: PrintOutPutOnConsole()
		{
			cout<<"this->radius:: "<<this->radius<<endl;
			cout<<"this->area :: "<<this->area<<endl;
		}

		Circle:: ~Circle()
		{
			this->radius=0.0;
			cout<<"inside dtor of circle class "<<endl;
		}


}//end of namespace
using namespace NCircle;
int main()
{
	Circle c1;
	//c1.AcceptInputFromConsole();
	c1.CalculateArea();
	c1.PrintOutPutOnConsole();

	double r;
	cout<< " Enter radius :: ";
	cin>>r;
	Circle c2(r);
	//c2.SetRadius(r);
	c2.CalculateArea();
	cout<<"c2 :: "<<endl;
	c2.PrintOutPutOnConsole();


	return 0;
}
