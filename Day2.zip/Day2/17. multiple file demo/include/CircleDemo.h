
#ifndef CIRCLEDEMO_H_
#define CIRCLEDEMO_H_


namespace NCircle
{
	class Circle
	{
		private:
			double radius;
			double area;

		public:
			Circle();
			Circle(double radius);
			void SetRadius(double radius);
			double GetRadius();
			void CalculateArea();
			void AcceptInputFromConsole();
			void PrintOutPutOnConsole();
			~Circle();
	};//end of class  Circle

}//end of Namespace CircleDemo


#endif /* CIRCLEDEMO_H_ */
