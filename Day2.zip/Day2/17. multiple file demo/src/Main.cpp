#include<iostream>
using namespace std;
#include"../include/CircleDemo.h"
#include"../include/CircleDemo.h"
using namespace NCircle;

int main()
{
	Circle c1;
	//c1.AcceptInputFromConsole();
	c1.CalculateArea();
	c1.PrintOutPutOnConsole();

	double r;
	cout<< " Enter radius :: ";
	cin>>r;
	Circle c2(r);
	//c2.SetRadius(r);
	c2.CalculateArea();
	cout<<"c2 :: "<<endl;
	c2.PrintOutPutOnConsole();


	return 0;
}
