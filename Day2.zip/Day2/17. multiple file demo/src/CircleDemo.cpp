#include <iostream>
using namespace std;
#include"../include/CircleDemo.h"
using namespace NCircle;

		//returntype ClassName::MemberFunName(datatype parameters)
		Circle:: Circle()
		{
			this->radius=5.0;
			this->area=0.0;
			cout<<"inside parameterless ctor of circle class "<<endl;
		}

		Circle::Circle(double radius)
		{
			this->radius=radius;
			this->area=0.0;
			cout<<"inside parameterized (one arguments) ctor of circle class "<<endl;
		}

		void Circle::SetRadius(double radius)
		{
			this->radius=radius;
		}

		double Circle:: GetRadius()
		{
			return this->radius;
		}
		void Circle:: CalculateArea()
		{
			this->area= 3.142 * this->radius * this->radius;
		}

		void  Circle:: AcceptInputFromConsole()
		{
			cout<<"Enter Radius ::";
			cin>>this->radius;
		}

		void Circle:: PrintOutPutOnConsole()
		{
			cout<<"this->radius:: "<<this->radius<<endl;
			cout<<"this->area :: "<<this->area<<endl;
		}

		Circle:: ~Circle()
		{
			this->radius=0.0;
			cout<<"inside dtor of circle class "<<endl;
		}



