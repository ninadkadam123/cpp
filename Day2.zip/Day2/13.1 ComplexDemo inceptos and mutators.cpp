#include <iostream>
using namespace std;
namespace NComplex
{
	class Complex
	{
		private:
		// variables or data member or fields
			int real;
			int imag;

		public:

			//2 setter methods modify the state of object (mutators)
			//void SetReal(Complex * const this, int real)
			void SetReal(int real)
			{
				this->real= real;
			}
			//void SetImag(Complex * const this,  int imag)
			void SetImag(int imag)
			{
				this->imag= imag;
			}

			//3. getter methods dont modify state of object (Inspectors)
			//int GetReal(Compelx *const this )
			int GetReal()
			{
				return this->real;
			}
			//int GetImag(Complex * const this)
			int GetImag()
			{
				return this->imag;
			}

	}; //end of Complex class
}//end of NComplex namespace
//using namespace NComplex;
int main()
{
	NComplex::Complex c1;
	using namespace NComplex;

	int real, imag;

	cout<<"Enter real :: ";
	cin>>real;
	cout<<"Enter imag :: ";
	cin>>imag;

	c1.SetReal(real);
	c1.SetImag(imag);



	cout<<"c1 :: using getter functions "<<endl;
	real= c1.GetReal();
	imag= c1.GetImag();

	cout<<"values of c1 :: using getter methods "<<endl;
	cout<<"real = "<<real<<endl;
	cout<<"imag = "<<imag<<endl;

	return 0;
}

