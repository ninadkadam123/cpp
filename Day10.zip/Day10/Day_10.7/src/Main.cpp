#include<iostream>
#include<typeinfo>
using namespace std;

class Base
{
public:
	virtual void print( )
	{
		cout<<"Inside Base::print"<<endl;
	}
};
class Derived : public Base
{
public:
	void print( )
	{
		cout<<"Inside Base::print"<<endl;
	}
};
int main( void )
{
	Base *ptr = NULL;
	cout<<typeid( ptr ).name()<<endl;	//P4Base
	cout<<typeid( *ptr ).name()<<endl;	//Exception : std::bad_typeid
	return 0;
}
int main5( void )
{
	Base *ptr = new Derived();
		cout<<typeid( ptr ).name()<<endl;	//P4Base
		//cout<<typeid( *ptr ).name()<<endl;	//4Base : If base is not polymorphic
		cout<<typeid( *ptr ).name()<<endl;	//7Derived: If base is  polymorphic
	return 0;
}
int main4( void )
{
	Derived *ptr = new Derived();
	cout<<typeid( ptr ).name()<<endl;	//P7Derived
	cout<<typeid( *ptr ).name()<<endl;	//7Derived
	return 0;
}
int main3( void )
{
	Derived d;
	cout<<typeid( d ).name()<<endl;	//7Derived
	return 0;
}
int main2( void )
{
	Base *ptr = new Base();
	cout<<typeid( ptr ).name()<<endl;	//P4Base
	cout<<typeid( *ptr ).name()<<endl;	//4Base
	return 0;
}

int main1( void )
{
	Base b;
	cout<<typeid( b ).name()<<endl;	//4Base
	return 0;
}
