#include<iostream>
#include<string>
using namespace std;

class Book
{
private:
	string title;
	float price;
	int pageCount;
public:
	Book( void )
	{	}
	void acceptRecord( void )
	{
		cout<<"Title	:	";
		cin>>this->title;
		cout<<"Price	:	";
		cin>>this->price;
		cout<<"Page Count	:	";
		cin>>this->pageCount;
	}
	void printRecord( void )
	{
		cout<<"Title	:	"<<this->title<<endl;
		cout<<"Price	:	"<<this->price<<endl;
		cout<<"Page Count	:	"<<this->pageCount<<endl;
	}
};
class Tape
{
private:
	string title;
	float price;
	int playTime;
public:
	Tape( void )
	{	}
	void acceptRecord( void )
	{
		cout<<"Title	:	";
		cin>>this->title;
		cout<<"Price	:	";
		cin>>this->price;
		cout<<"Play Time	:	";
		cin>>this->playTime;
	}
	void printRecord( void )
	{
		cout<<"Title	:	"<<this->title<<endl;
		cout<<"Price	:	"<<this->price<<endl;
		cout<<"Play Time	:	"<<this->playTime<<endl;
	}
};
int menu_list( void )
{
	int choice;
	cout<<"0.Exit"<<endl;
	cout<<"1.Book"<<endl;
	cout<<"2.Tape"<<endl;
	cout<<"Enter choice	:	";
	cin>>choice;
	return choice;
}
int main( void )
{
	int choice;
	while( ( choice = ::menu_list( ) ) != 0 )
	{
		Book book;
		Tape tape;
		switch( choice )
		{
		case 1:
			book.acceptRecord();
			book.printRecord();
			break;
		case 2:
			tape.acceptRecord();
			tape.printRecord();
			break;
		}
	}
	return 0;
}
