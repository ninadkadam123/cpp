#include<iostream>
using namespace std;
class Complex
{
private:
	int real;
	int imag;
public:
	Complex( void )
	{
		this->real = 10;
		this->imag = 20;
	}
	void printRecord( void )
	{
		cout<<"Real Number	:	"<<this->real<<endl;
		cout<<"Imag Number	:	"<<this->imag<<endl;
	}
};
int main( void )
{
	Complex c1;
	c1.printRecord();

	Complex *ptrComplex = &c1;
	//int *ptrInt = ( int *)ptrComplex;	//C-Style
	int *ptrInt = reinterpret_cast<int*>( ptrComplex );	//C++ Style
	*ptrInt = 50;
	ptrInt = ptrInt + 1;
	*ptrInt = 60;

	c1.printRecord();
	return 0;
}
