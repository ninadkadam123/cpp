#include<iostream>
#include<string>
using namespace std;

//template<typename T>	//OK
template<class T>	//T -> Type Parameter
void swap_object( T &x, T &y )
{
	T temp = x;
	x = y;
	y = temp;
}
int main( void )
{
	int a = 10;
	int b = 20;
	swap_object<int>( a, b );	//int -> Type argument
	cout<<"A	:	"<<a<<endl;
	cout<<"B	:	"<<b<<endl;
	return 0;
}
