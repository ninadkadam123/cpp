
#include"../include/Array.h"
int main( void )
{
	Array<int> a1( 3 );
	a1.acceptRecord( );
	a1.printRecord( );
	return 0;
}
