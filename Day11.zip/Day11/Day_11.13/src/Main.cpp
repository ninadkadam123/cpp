#include<iostream>
using namespace std;
class Complex
{
private:
	int real;
	int imag;
public:
	Complex( void )
	{
		this->real = 0;
		this->imag = 0;
	}
	Complex( int real, int imag )
	{
		this->real = real;
		this->imag = imag;
	}
	//Complex *const this = &c1
	//Complex &other = c2;
	Complex operator+( Complex &other )
	{
		Complex temp;
		temp.real = this->real + other.real;
		temp.imag = this->imag + other.imag;
		return temp;
	}
	Complex operator+( int value )
	{
		Complex temp;
		temp.real = this->real + value;
		temp.imag = this->imag + value;
		return temp;
	}
	//Complex *const this = &c1
	//Complex &other = c2
	bool operator==( Complex &other )
	{
		return this->real == other.real && this->imag == other.imag;
	}
	Complex operator++( void )//Pre-Increment
	{
		Complex temp;
		temp.real = ++ this->real;
		temp.imag = ++ this->imag;
		return temp;
	}
	Complex operator++( int )//Post-Increment
	{
		Complex temp;
		temp.real =  this->real ++;
		temp.imag =  this->imag ++;
		return temp;
	}
	void printRecord( void )
	{
		cout<<"Real Number	:	"<<this->real<<endl;
		cout<<"Imag Number	:	"<<this->imag<<endl;
	}
};

int main( void )
{
	Complex c1(10,20);
	Complex c2 = ++ c1;	//c2 = c1.operator++( );
	Complex c3 = c1 ++;	//c2 = c1.operator++( );
	c3.printRecord();
	return 0;
}
int main2( void )
{
	Complex c1( 10, 20 );
	Complex c2 = c1 + 5;	//c2 = c1.operator+( 5 )
	c2.printRecord();
	return 0;
}
int main1( void )
{
	Complex c1(10,20);
	Complex c2(10,20);
	//bool status =  c1 == c2;	//status = c1.operator==( c2 )
	cout<< ( c1 == c2 ? "Equal" : "Not Equal")<<endl;
	return 0;
}
